<?php

$schema['komtet_kassa'] = array (
    'permissions' => 'view_orders'
);

return $schema;
