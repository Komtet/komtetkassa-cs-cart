<?php

$schema['komtet_kassa'] = array(
    'allow' => true,
    'areas' => array('C')
);

return $schema;