<?php

$schema = array(
    '0' => array(
        'name' => 'ОСН',
    ),
    '1' => array(
        'name' => 'УСН доход',
    ),
    '2' => array(
        'name' => 'УСН доход - расход',
    ),
    '3' => array(
        'name' => 'ЕНВД',
    ),
    '4' => array(
        'name' => 'ЕСН',
    ),
    '5' => array(
        'name' => 'Патент',
    ),
);

return $schema;
