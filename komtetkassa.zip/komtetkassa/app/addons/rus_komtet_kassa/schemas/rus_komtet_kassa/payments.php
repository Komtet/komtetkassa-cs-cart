<?php

$schema = array(
    '1' => array(
        'name' => "test",
    ),
);

return $schema;
