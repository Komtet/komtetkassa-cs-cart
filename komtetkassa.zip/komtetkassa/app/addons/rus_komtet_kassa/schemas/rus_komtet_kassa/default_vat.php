<?php

$schema = array(
    '0' => array(
        'name' => 'НДС 0%',
    ),
    '10' => array(
        'name' => 'НДС 10%',
    ),
    '18' => array(
        'name' => 'НДС 18%',
    ),
    '110' => array(
        'name' => 'НДС 10/110',
    ),
    '118' => array(
        'name' => 'НДС 18/118',
    ),
    'no' => array(
        'name' => 'Без НДС',
    ),
);

return $schema;
